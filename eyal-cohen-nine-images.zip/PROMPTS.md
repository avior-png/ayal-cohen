# Final prompt set

Generated using the built-in ImageGen tool, one generation per asset.

## 01-home-what-we-check-16x9

Use case: photorealistic-natural.
Asset type: website card image, exact landscape 16:9 composition.
Style/medium: realistic premium editorial photography, believable Israeli financial-planning work environment.
Color palette: deep navy, light blue, warm ivory, light oak.
Lighting/mood: soft daylight from a window, neutral-warm color grade, calm, precise, understated.
Materials/textures: real paper fibers, matte navy stationery, natural light-oak grain.
Constraints: no text overlays, no logos, no watermarks, no trees, no plants, no coins, no gold effects, no holograms, no paper sculptures, no fictional charts, no readable personal data, no readable screens, no famous or recognizable people, no camera-facing smiles, no staged luxury. If documents appear, their content must be angled away, shallow-focus blurred, or visually illegible. Preserve generous crop-safe margins.
Primary request: several ordinary pension and insurance report pages spread in a controlled, believable way on a light-oak desk, photographed from above at a diagonal. One closed navy folder partly visible, a pair of simple reading glasses at the edge. No person and no hands. The pages show only soft gray typographic texture and table-like structure that is completely illegible, with no charts or numbers. Clean single visual story: gathering all existing reports for review. Keep the center uncluttered and the scene natural.

## 02-home-what-you-get-16x9

Use case: photorealistic-natural.
Asset type: website card image, exact landscape 16:9 composition.
Style/medium: realistic premium editorial photography, believable Israeli financial-planning work environment.
Color palette: deep navy, light blue, warm ivory, light oak.
Lighting/mood: soft daylight from a window, neutral-warm color grade, calm, precise, understated.
Materials/textures: real paper fibers, matte navy stationery, natural light-oak grain.
Constraints: no text overlays, no logos, no watermarks, no trees, no plants, no coins, no gold effects, no holograms, no paper sculptures, no fictional charts, no readable personal data, no readable screens, no famous or recognizable people, no camera-facing smiles, no staged luxury. If documents appear, their content must be angled away, shallow-focus blurred, or visually illegible. Preserve generous crop-safe margins.
Primary request: one single, neatly prepared personal planning document centered on a light-oak desk, photographed from above at a slight diagonal. The document has an ivory cover and a subtle navy binding edge; no title or readable content. A dark navy pen and one muted light-blue page marker rest beside it. No hands, no people, no extra paper stacks. The scene communicates one organized final plan through real stationery, not graphics. Minimal, tactile and believable.

## 03-home-what-it-requires-16x9

Use case: photorealistic-natural.
Asset type: website card image, exact landscape 16:9 composition.
Style/medium: realistic premium editorial photography, believable Israeli financial-planning work environment.
Color palette: deep navy, light blue, warm ivory, light oak.
Lighting/mood: soft daylight from a window, neutral-warm color grade, calm, precise, understated.
Materials/textures: real paper fibers, matte navy stationery, natural light-oak grain.
Constraints: no text overlays, no logos, no watermarks, no trees, no plants, no coins, no gold effects, no holograms, no paper sculptures, no fictional charts, no readable personal data, no readable screens, no famous or recognizable people, no camera-facing smiles, no staged luxury. If documents appear, their content must be angled away, shallow-focus blurred, or visually illegible. Preserve generous crop-safe margins.
Primary request: a normal modern smartphone lying face-up on a light-oak desk beside a small open warm-ivory notebook and navy pen. Phone screen is dark and fully unreadable, with no app interface. Notebook pages are blank with no writing. Soft window light, slight natural shadow, everyday uncluttered setup that communicates a short phone conversation. No hands or people. Simple editorial still life, not a product advertisement.

## 04-service-full-retirement-planning-4x3

Use case: photorealistic-natural.
Asset type: service-page editorial image, exact landscape 4:3 composition.
Style/medium: realistic premium editorial photography, authentic retirement-planning work, no advertising gloss.
Color palette: deep navy, light blue, warm ivory, light oak.
Lighting/mood: soft daylight from a window, neutral-warm color grade, calm and trustworthy.
Constraints: natural skin and anatomy. No text overlays, logos, watermarks, trees, plants, coins, gold effects, holograms, paper sculptures, fictional charts, readable personal data, readable screens, famous or recognizable people, camera-facing smiles, staged luxury, handshakes. Documents must be angled away or softly out of focus and never readable.
Primary request: over-the-shoulder candid view of a retirement adviser in a navy blazer meeting a mature couple aged about 58–64 at a modest light-oak table. The adviser is seen from behind with face outside frame, calmly arranging a few ordinary documents into one navy folder while the couple follows attentively. The couple interacts with the adviser, not the camera. Believable office, no luxury boardroom. Medium-wide composition with full natural hands visible. This depicts a comprehensive planning meeting without implying the adviser is a specific real person.

## 05-service-rights-fixation-4x3

Use case: photorealistic-natural.
Asset type: service-page editorial image, exact landscape 4:3 composition.
Style/medium: realistic premium editorial photography, authentic retirement-planning work, no advertising gloss.
Color palette: deep navy, light blue, warm ivory, light oak.
Lighting/mood: soft daylight from a window, neutral-warm color grade, calm and trustworthy.
Constraints: natural skin and anatomy. No text overlays, logos, watermarks, trees, plants, coins, gold effects, holograms, paper sculptures, fictional charts, readable personal data, readable screens, famous or recognizable people, camera-facing smiles, staged luxury, handshakes. Documents must be angled away or softly out of focus and never readable.
Primary request: close editorial detail of a mature client's natural hand and a professional's hand reviewing one official-looking but entirely illegible retirement form on a light-oak desk. A simple calculator is present with its display turned away, plus two small blank page tabs in navy and light blue marking sections. The professional points with a navy pen to a single line area, while the client rests a hand nearby. Do not recreate any real government form, emblem, heading, number or personal information. The scene communicates careful review of retirement rights and exemptions.

## 06-service-retirement-tax-190-4x3

Use case: photorealistic-natural.
Asset type: service-page editorial image, exact landscape 4:3 composition.
Style/medium: realistic premium editorial photography, authentic retirement-planning work, no advertising gloss.
Color palette: deep navy, light blue, warm ivory, light oak.
Lighting/mood: soft daylight from a window, neutral-warm color grade, calm and trustworthy.
Constraints: natural skin and anatomy. No text overlays, logos, watermarks, trees, plants, coins, gold effects, holograms, paper sculptures, fictional charts, readable personal data, readable screens, famous or recognizable people, camera-facing smiles, staged luxury, handshakes. Documents must be angled away or softly out of focus and never readable.
Primary request: realistic side-overhead photograph of a financial professional comparing two sets of fully illegible tax and pension papers on a light-oak desk. Two natural hands: one operates a normal calculator whose display is angled away and unreadable; the other holds a pencil beside the documents. One matte navy folder, one light-blue divider, otherwise uncluttered. No people’s faces. The visual communicates comparing tax alternatives carefully, without fake charts or numerical claims.

## 07-service-severance-simulated-retirement-4x3

Use case: photorealistic-natural.
Asset type: service-page editorial image, exact landscape 4:3 composition.
Style/medium: realistic premium editorial photography, authentic retirement-planning work, no advertising gloss.
Color palette: deep navy, light blue, warm ivory, light oak.
Lighting/mood: soft daylight from a window, neutral-warm color grade, calm and trustworthy.
Constraints: natural skin and anatomy. No text overlays, logos, watermarks, trees, plants, coins, gold effects, holograms, paper sculptures, fictional charts, readable personal data, readable screens, famous or recognizable people, camera-facing smiles, staged luxury, handshakes. Documents must be angled away or softly out of focus and never readable.
Primary request: authentic editorial photograph of a mature employee around 60 in a light-blue shirt seated at a modest desk with a professional adviser partly visible from the side. Between them are two small, orderly stacks of completely illegible employment and pension documents, one held in a navy folder and one in an ivory folder. The employee is thoughtfully listening and touching the edge of one document; adviser gestures naturally with an open hand. No camera gaze, no handshake, no dramatic emotion. The scene communicates coordinating severance and pension decisions at a career transition.

## 08-service-pension-portfolio-adjustment-4x3

Use case: photorealistic-natural.
Asset type: service-page editorial image, exact landscape 4:3 composition.
Style/medium: realistic premium editorial photography, authentic retirement-planning work, no advertising gloss.
Color palette: deep navy, light blue, warm ivory, light oak.
Lighting/mood: soft daylight from a window, neutral-warm color grade, calm and trustworthy.
Constraints: natural skin and anatomy. No text overlays, logos, watermarks, trees, plants, coins, gold effects, holograms, paper sculptures, fictional charts, readable personal data, readable screens, famous or recognizable people, camera-facing smiles, staged luxury, handshakes. Documents must be angled away or softly out of focus and never readable.
Primary request: overhead-oblique editorial detail of several ordinary, completely illegible pension statements from different sources being carefully consolidated into one open navy folder on a light-oak desk. A professional's two natural hands align the papers; one light-blue divider and a closed notebook are present. No face, no calculator, no graphs or readable institution marks. Controlled, organized composition that communicates bringing a scattered pension portfolio into one coherent structure.

## 09-contact-action-4x3

Use case: photorealistic-natural.
Asset type: service-page editorial image, exact landscape 4:3 composition.
Style/medium: realistic premium editorial photography, authentic retirement-planning work, no advertising gloss.
Color palette: deep navy, light blue, warm ivory, light oak.
Lighting/mood: soft daylight from a window, neutral-warm color grade, calm and trustworthy.
Constraints: natural skin and anatomy. No text overlays, logos, watermarks, trees, plants, coins, gold effects, holograms, paper sculptures, fictional charts, readable personal data, readable screens, famous or recognizable people, camera-facing smiles, staged luxury, handshakes. Documents must be angled away or softly out of focus and never readable.
Primary request: close natural editorial photograph of an adult around 58 seated at a light-oak home desk, shown from the side and cropped from shoulders down, typing a short message on a smartphone held naturally in both hands. The phone screen faces away and is completely unreadable. Beside it: a small open blank notebook, navy pen and simple ceramic water cup. Warm ivory shirt with a light-blue cuff detail. The action is clear and immediate, anatomy realistic, no face required, uncluttered and approachable.

